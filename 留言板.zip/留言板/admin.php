<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>留言管理后台</title>
    <style>
        body { background: #f0f2f5; font-family: sans-serif; padding: 40px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px; }
        .card { background: white; border-radius: 12px; padding: 15px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); text-align: center; }
        .card img { width: 100%; border: 1px solid #f0f0f0; border-radius: 8px; background: #fafafa; }
        .time { margin-top: 10px; font-size: 13px; color: #888; }
        h1 { font-weight: 300; color: #333; }
    </style>
</head>
<body>
    <h1>所有留言轨迹</h1>
    <hr>
    <div class="grid">
        <?php
        $files = glob("messages/*.png");
        // 按时间排序（新的在前）
        usort($files, function($a, $b) {
            return filemtime($b) - filemtime($a);
        });

        if (empty($files)) {
            echo "<p>暂无留言</p>";
        }

        foreach ($files as $file) {
            $time = date("Y-m-d H:i:s", filemtime($file));
            echo "<div class='card'>
                    <img src='$file' alt='手写笔迹'>
                    <div class='time'>$time</div>
                  </div>";
        }
        ?>
    </div>
</body>
</html>