<?php
header('Content-Type: application/json');

// 1. 创建存储文件夹
$savePath = 'messages/';
if (!is_dir($savePath)) {
    mkdir($savePath, 0755, true);
}

// 2. 获取数据
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (isset($data['image'])) {
    $base64Data = $data['image'];
    
    // 解析 Base64
    if (preg_match('/^data:image\/(\w+);base64,/', $base64Data, $type)) {
        $base64Data = substr($base64Data, strpos($base64Data, ',') + 1);
        $type = strtolower($type[1]); // png

        $base64Data = base64_decode($base64Data);
        if ($base64Data === false) {
            echo json_encode(['status' => 'error', 'msg' => '解码失败']);
            exit;
        }
    } else {
        echo json_encode(['status' => 'error', 'msg' => '格式错误']);
        exit;
    }

    // 3. 存储文件（以时间戳命名）
    $fileName = $savePath . date('Ymd_His') . '_' . uniqid() . '.png';
    file_put_contents($fileName, $base64Data);

    echo json_encode(['status' => 'success', 'file' => $fileName]);
} else {
    echo json_encode(['status' => 'error', 'msg' => '无数据']);
}